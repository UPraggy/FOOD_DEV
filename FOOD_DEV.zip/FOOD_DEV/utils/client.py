class Client_functions: 
    def create():
        print("A")
    def select():
        print("A")
    def update():
        print("A")
    def delete():
        print("A")