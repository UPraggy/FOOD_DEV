class Order_functions:
    def create():
        print("A")
    def status():
        print("A")
    def update():
        print("A")
    def select():
        print("A")
    def cancel():
        print("A")    